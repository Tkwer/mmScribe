class ASRModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  sos : int
  eos : int
  vocab_size : int
  ignore_id : int
  ctc_weight : float
  reverse_weight : float
  encoder : __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder
  decoder : __torch__.wenet.transformer.decoder.___torch_mangle_26.TransformerDecoder
  ctc : __torch__.wenet.transformer.ctc.___torch_mangle_27.CTC
  criterion_att : __torch__.wenet.transformer.label_smoothing_loss.LabelSmoothingLoss
  def forward(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel,
    speech: Tensor,
    speech_lengths: Tensor,
    text: Tensor,
    text_lengths: Tensor) -> Tuple[Optional[Tensor], Optional[Tensor], Optional[Tensor]]:
    _0 = torch.eq(torch.dim(text_lengths), 1)
    if _0:
      pass
    else:
      _1 = torch.add("AssertionError: ", str(torch.size(text_lengths)))
      ops.prim.RaiseException(_1)
    _2 = torch.eq((torch.size(speech))[0], (torch.size(speech_lengths))[0])
    if _2:
      _4 = torch.eq((torch.size(speech_lengths))[0], (torch.size(text))[0])
      _3 = _4
    else:
      _3 = False
    if _3:
      _6 = torch.eq((torch.size(text))[0], (torch.size(text_lengths))[0])
      _5 = _6
    else:
      _5 = False
    if _5:
      pass
    else:
      _7 = (torch.size(speech), torch.size(speech_lengths), torch.size(text), torch.size(text_lengths))
      _8 = torch.add("AssertionError: ", str(_7))
      ops.prim.RaiseException(_8)
    encoder = self.encoder
    _9 = (encoder).forward(speech, speech_lengths, 0, -1, )
    encoder_out, encoder_mask, = _9
    encoder_out_lens = torch.sum(torch.squeeze(encoder_mask, 1), [1])
    ctc_weight = self.ctc_weight
    if torch.ne(ctc_weight, 1.):
      _10 = (self)._calc_att_loss(encoder_out, encoder_mask, text, text_lengths, )
      loss_att0, acc_att, = _10
      loss_att : Optional[Tensor] = loss_att0
    else:
      loss_att = None
    ctc_weight0 = self.ctc_weight
    if torch.ne(ctc_weight0, 0.):
      ctc = self.ctc
      loss_ctc0 = (ctc).forward(encoder_out, encoder_out_lens, text, text_lengths, )
      loss_ctc : Optional[Tensor] = loss_ctc0
    else:
      loss_ctc = None
    if torch.__is__(loss_ctc, None):
      loss, loss_att1, loss_ctc1 = loss_att, loss_att, loss_ctc
    else:
      loss_ctc2 = unchecked_cast(Tensor, loss_ctc)
      if torch.__is__(loss_att, None):
        loss0, loss_att2 = loss_ctc2, loss_att
      else:
        loss_att3 = unchecked_cast(Tensor, loss_att)
        ctc_weight1 = self.ctc_weight
        _11 = torch.mul(loss_ctc2, ctc_weight1)
        ctc_weight2 = self.ctc_weight
        _12 = torch.mul(loss_att3, torch.sub(1, ctc_weight2))
        loss0, loss_att2 = torch.add(_11, _12), loss_att3
      loss, loss_att1, loss_ctc1 = loss0, loss_att2, loss_ctc2
    return (loss, loss_att1, loss_ctc1)
  def ctc_activation(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel,
    xs: Tensor) -> Tensor:
    ctc = self.ctc
    return (ctc).log_softmax(xs, )
  def eos_symbol(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel) -> int:
    return self.eos
  def forward_attention_decoder(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel,
    hyps: Tensor,
    hyps_lens: Tensor,
    encoder_out: Tensor,
    reverse_weight: float=0.) -> Tuple[Tensor, Tensor]:
    _13 = __torch__.wenet.utils.common.reverse_pad_list
    _14 = __torch__.wenet.utils.common.add_sos_eos
    _15 = __torch__.torch.nn.functional.log_softmax
    _16 = torch.eq(torch.size(encoder_out, 0), 1)
    if _16:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    num_hyps = torch.size(hyps, 0)
    _17 = torch.eq(torch.size(hyps_lens, 0), num_hyps)
    if _17:
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    encoder_out0 = torch.repeat(encoder_out, [num_hyps, 1, 1])
    _18 = torch.size(encoder_out0, 1)
    _19 = ops.prim.device(encoder_out0)
    encoder_mask = torch.ones([num_hyps, 1, _18], dtype=11, layout=None, device=_19)
    r_hyps_lens = torch.sub(hyps_lens, 1)
    r_hyps = torch.slice(torch.slice(hyps), 1, 1)
    ignore_id = self.ignore_id
    r_hyps0 = _13(r_hyps, r_hyps_lens, float(ignore_id), )
    sos = self.sos
    eos = self.eos
    ignore_id0 = self.ignore_id
    _20 = _14(r_hyps0, sos, eos, ignore_id0, )
    r_hyps1, _21, = _20
    decoder = self.decoder
    _22 = (decoder).forward(encoder_out0, encoder_mask, hyps, hyps_lens, r_hyps1, reverse_weight, )
    decoder_out, r_decoder_out, _23, = _22
    decoder_out0 = _15(decoder_out, -1, 3, None, )
    r_decoder_out0 = _15(r_decoder_out, -1, 3, None, )
    return (decoder_out0, r_decoder_out0)
  def forward_encoder_chunk(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel,
    xs: Tensor,
    offset: int,
    required_cache_size: int,
    subsampling_cache: Optional[Tensor]=None,
    elayers_output_cache: Optional[List[Tensor]]=None,
    conformer_cnn_cache: Optional[List[Tensor]]=None) -> Tuple[Tensor, Tensor, List[Tensor], List[Tensor]]:
    encoder = self.encoder
    _24 = (encoder).forward_chunk(xs, offset, required_cache_size, subsampling_cache, elayers_output_cache, conformer_cnn_cache, )
    return _24
  def is_bidirectional_decoder(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel) -> bool:
    return False
  def right_context(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel) -> int:
    encoder = self.encoder
    embed = encoder.embed
    return embed.right_context
  def sos_symbol(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel) -> int:
    return self.sos
  def subsampling_rate(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel) -> int:
    encoder = self.encoder
    embed = encoder.embed
    return embed.subsampling_rate
  def _calc_att_loss(self: __torch__.wenet.transformer.asr_model.___torch_mangle_28.ASRModel,
    encoder_out: Tensor,
    encoder_mask: Tensor,
    ys_pad: Tensor,
    ys_pad_lens: Tensor) -> Tuple[Tensor, float]:
    _25 = __torch__.wenet.utils.common.add_sos_eos
    _26 = __torch__.wenet.utils.common.reverse_pad_list
    _27 = __torch__.wenet.utils.common.th_accuracy
    sos = self.sos
    eos = self.eos
    ignore_id = self.ignore_id
    ys_in_pad, ys_out_pad, = _25(ys_pad, sos, eos, ignore_id, )
    ys_in_lens = torch.add(ys_pad_lens, 1)
    ignore_id1 = self.ignore_id
    r_ys_pad = _26(ys_pad, ys_pad_lens, float(ignore_id1), )
    sos0 = self.sos
    eos0 = self.eos
    ignore_id2 = self.ignore_id
    _28 = _25(r_ys_pad, sos0, eos0, ignore_id2, )
    r_ys_in_pad, r_ys_out_pad, = _28
    decoder = self.decoder
    reverse_weight = self.reverse_weight
    _29 = (decoder).forward(encoder_out, encoder_mask, ys_in_pad, ys_in_lens, r_ys_in_pad, reverse_weight, )
    decoder_out, r_decoder_out, _30, = _29
    criterion_att = self.criterion_att
    loss_att = (criterion_att).forward(decoder_out, ys_out_pad, )
    r_loss_att = torch.tensor(0.)
    reverse_weight0 = self.reverse_weight
    if torch.gt(reverse_weight0, 0.):
      criterion_att0 = self.criterion_att
      r_loss_att1 = (criterion_att0).forward(r_decoder_out, r_ys_out_pad, )
      r_loss_att0 = r_loss_att1
    else:
      r_loss_att0 = r_loss_att
    reverse_weight1 = self.reverse_weight
    _31 = torch.mul(loss_att, torch.sub(1, reverse_weight1))
    reverse_weight2 = self.reverse_weight
    _32 = torch.mul(r_loss_att0, reverse_weight2)
    loss_att4 = torch.add(_31, _32)
    vocab_size = self.vocab_size
    _33 = torch.view(decoder_out, [-1, vocab_size])
    ignore_id3 = self.ignore_id
    acc_att = _27(_33, ys_out_pad, ignore_id3, )
    return (loss_att4, acc_att)
