class LabelSmoothingLoss(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  padding_idx : int
  confidence : float
  smoothing : float
  size : int
  normalize_length : bool
  criterion : __torch__.torch.nn.modules.loss.KLDivLoss
  def forward(self: __torch__.wenet.transformer.label_smoothing_loss.LabelSmoothingLoss,
    x: Tensor,
    target: Tensor) -> Tensor:
    _0 = torch.size(x, 2)
    size = self.size
    if torch.eq(_0, size):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    batch_size = torch.size(x, 0)
    size0 = self.size
    x0 = torch.view(x, [-1, size0])
    target0 = torch.view(target, [-1])
    true_dist = torch.zeros_like(x0)
    smoothing = self.smoothing
    size1 = self.size
    _1 = torch.div(smoothing, torch.sub(size1, 1))
    _2 = torch.fill_(true_dist, _1)
    padding_idx = self.padding_idx
    ignore = torch.eq(target0, padding_idx)
    total = torch.sub(torch.len(target0), torch.item(torch.sum(ignore)))
    target1 = torch.masked_fill(target0, ignore, 0)
    _3 = torch.unsqueeze(target1, 1)
    confidence = self.confidence
    _4 = torch.scatter_(true_dist, 1, _3, confidence)
    criterion = self.criterion
    kl = (criterion).forward(torch.log_softmax(x0, 1), true_dist, )
    normalize_length = self.normalize_length
    if normalize_length:
      denom = total
    else:
      denom = batch_size
    _5 = torch.masked_fill(kl, torch.unsqueeze(ignore, 1), 0)
    return torch.div(torch.sum(_5), denom)
