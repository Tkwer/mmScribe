class ConformerEncoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  _output_size : int
  normalize_before : bool
  static_chunk_size : int
  use_dynamic_chunk : bool
  use_dynamic_left_chunk : bool
  global_cmvn : __torch__.wenet.transformer.cmvn.GlobalCMVN
  embed : __torch__.wenet.transformer.subsampling.___torch_mangle_16.Conv2dSubsampling4
  after_norm : __torch__.torch.nn.modules.normalization.LayerNorm
  encoders : __torch__.torch.nn.modules.container.___torch_mangle_20.ModuleList
  def forward(self: __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder,
    xs: Tensor,
    xs_lens: Tensor,
    decoding_chunk_size: int=0,
    num_decoding_left_chunks: int=-1) -> Tuple[Tensor, Tensor]:
    _0 = __torch__.wenet.utils.mask.make_pad_mask
    _1 = __torch__.wenet.utils.mask.add_optional_chunk_mask
    masks = torch.bitwise_not(torch.unsqueeze(_0(xs_lens, ), 1))
    global_cmvn = self.global_cmvn
    xs0 = (global_cmvn).forward(xs, )
    embed = self.embed
    xs1, pos_emb, masks0, = (embed).forward(xs0, masks, 0, )
    use_dynamic_chunk = self.use_dynamic_chunk
    use_dynamic_left_chunk = self.use_dynamic_left_chunk
    static_chunk_size = self.static_chunk_size
    chunk_masks = _1(xs1, masks0, use_dynamic_chunk, use_dynamic_left_chunk, decoding_chunk_size, static_chunk_size, num_decoding_left_chunks, )
    encoders = self.encoders
    _00 = getattr(encoders, "0")
    _10 = getattr(encoders, "1")
    _2 = getattr(encoders, "2")
    _3 = getattr(encoders, "3")
    _4 = getattr(encoders, "4")
    _5 = getattr(encoders, "5")
    _6 = (_00).forward(xs1, chunk_masks, pos_emb, masks0, None, None, )
    xs2, chunk_masks0, _7, = _6
    _8 = (_10).forward(xs2, chunk_masks0, pos_emb, masks0, None, None, )
    xs3, chunk_masks1, _9, = _8
    _11 = (_2).forward(xs3, chunk_masks1, pos_emb, masks0, None, None, )
    xs4, chunk_masks2, _12, = _11
    _13 = (_3).forward(xs4, chunk_masks2, pos_emb, masks0, None, None, )
    xs5, chunk_masks3, _14, = _13
    _15 = (_4).forward(xs5, chunk_masks3, pos_emb, masks0, None, None, )
    xs6, chunk_masks4, _16, = _15
    _17 = (_5).forward(xs6, chunk_masks4, pos_emb, masks0, None, None, )
    xs7, chunk_masks5, _18, = _17
    normalize_before = self.normalize_before
    if normalize_before:
      after_norm = self.after_norm
      xs8 = (after_norm).forward(xs7, )
    else:
      xs8 = xs7
    return (xs8, masks0)
  def forward_chunk(self: __torch__.wenet.transformer.encoder.___torch_mangle_21.ConformerEncoder,
    xs: Tensor,
    offset: int,
    required_cache_size: int,
    subsampling_cache: Optional[Tensor]=None,
    elayers_output_cache: Optional[List[Tensor]]=None,
    conformer_cnn_cache: Optional[List[Tensor]]=None) -> Tuple[Tensor, Tensor, List[Tensor], List[Tensor]]:
    if torch.eq(torch.size(xs, 0), 1):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    _14 = torch.size(xs, 1)
    _15 = ops.prim.device(xs)
    tmp_masks = torch.ones([1, _14], dtype=11, layout=None, device=_15)
    tmp_masks0 = torch.unsqueeze(tmp_masks, 1)
    global_cmvn = self.global_cmvn
    xs9 = (global_cmvn).forward(xs, )
    embed = self.embed
    _16 = (embed).forward(xs9, tmp_masks0, offset, )
    xs10, pos_emb, _17, = _16
    _18 = torch.__isnot__(subsampling_cache, None)
    if _18:
      subsampling_cache0 = unchecked_cast(Tensor, subsampling_cache)
      cache_size0 = torch.size(subsampling_cache0, 1)
      xs12 = torch.cat([subsampling_cache0, xs10], 1)
      cache_size, xs11 = cache_size0, xs12
    else:
      cache_size, xs11 = 0, xs10
    embed0 = self.embed
    pos_emb0 = (embed0).position_encoding(torch.sub(offset, cache_size), torch.size(xs11, 1), )
    if torch.lt(required_cache_size, 0):
      next_cache_start = 0
    else:
      if torch.eq(required_cache_size, 0):
        next_cache_start0 = torch.size(xs11, 1)
      else:
        _19 = torch.sub(torch.size(xs11, 1), required_cache_size)
        next_cache_start0 = ops.prim.max(_19, 0)
      next_cache_start = next_cache_start0
    _20 = torch.slice(torch.slice(xs11), 1, next_cache_start)
    r_subsampling_cache = torch.slice(_20, 2)
    _21 = torch.size(xs11, 1)
    _22 = ops.prim.device(xs11)
    masks = torch.ones([1, _21], dtype=11, layout=None, device=_22)
    masks1 = torch.unsqueeze(masks, 1)
    r_elayers_output_cache = annotate(List[Tensor], [])
    r_conformer_cnn_cache = annotate(List[Tensor], [])
    encoders = self.encoders
    _0 = getattr(encoders, "0")
    _1 = getattr(encoders, "1")
    _2 = getattr(encoders, "2")
    _3 = getattr(encoders, "3")
    _4 = getattr(encoders, "4")
    _5 = getattr(encoders, "5")
    _23 = torch.__is__(elayers_output_cache, None)
    if _23:
      attn_cache, elayers_output_cache0 = None, elayers_output_cache
    else:
      elayers_output_cache1 = unchecked_cast(List[Tensor], elayers_output_cache)
      attn_cache, elayers_output_cache0 = elayers_output_cache1[0], elayers_output_cache1
    _24 = torch.__is__(conformer_cnn_cache, None)
    if _24:
      cnn_cache, conformer_cnn_cache0 = None, conformer_cnn_cache
    else:
      conformer_cnn_cache1 = unchecked_cast(List[Tensor], conformer_cnn_cache)
      cnn_cache, conformer_cnn_cache0 = conformer_cnn_cache1[0], conformer_cnn_cache1
    _25 = (_0).forward(xs11, masks1, pos_emb0, None, attn_cache, cnn_cache, )
    xs13, _26, new_cnn_cache, = _25
    _27 = torch.slice(torch.slice(xs13), 1, next_cache_start)
    _28 = torch.append(r_elayers_output_cache, torch.slice(_27, 2))
    _29 = torch.append(r_conformer_cnn_cache, new_cnn_cache)
    _30 = torch.__is__(elayers_output_cache0, None)
    if _30:
      attn_cache0, elayers_output_cache2 = None, elayers_output_cache0
    else:
      elayers_output_cache3 = unchecked_cast(List[Tensor], elayers_output_cache0)
      attn_cache0, elayers_output_cache2 = elayers_output_cache3[1], elayers_output_cache3
    _31 = torch.__is__(conformer_cnn_cache0, None)
    if _31:
      cnn_cache0, conformer_cnn_cache2 = None, conformer_cnn_cache0
    else:
      conformer_cnn_cache3 = unchecked_cast(List[Tensor], conformer_cnn_cache0)
      cnn_cache0, conformer_cnn_cache2 = conformer_cnn_cache3[1], conformer_cnn_cache3
    _32 = (_1).forward(xs13, masks1, pos_emb0, None, attn_cache0, cnn_cache0, )
    xs14, _33, new_cnn_cache0, = _32
    _34 = torch.slice(torch.slice(xs14), 1, next_cache_start)
    _35 = torch.append(r_elayers_output_cache, torch.slice(_34, 2))
    _36 = torch.append(r_conformer_cnn_cache, new_cnn_cache0)
    _37 = torch.__is__(elayers_output_cache2, None)
    if _37:
      attn_cache1, elayers_output_cache4 = None, elayers_output_cache2
    else:
      elayers_output_cache5 = unchecked_cast(List[Tensor], elayers_output_cache2)
      attn_cache1, elayers_output_cache4 = elayers_output_cache5[2], elayers_output_cache5
    _38 = torch.__is__(conformer_cnn_cache2, None)
    if _38:
      cnn_cache1, conformer_cnn_cache4 = None, conformer_cnn_cache2
    else:
      conformer_cnn_cache5 = unchecked_cast(List[Tensor], conformer_cnn_cache2)
      cnn_cache1, conformer_cnn_cache4 = conformer_cnn_cache5[2], conformer_cnn_cache5
    _39 = (_2).forward(xs14, masks1, pos_emb0, None, attn_cache1, cnn_cache1, )
    xs15, _40, new_cnn_cache1, = _39
    _41 = torch.slice(torch.slice(xs15), 1, next_cache_start)
    _42 = torch.append(r_elayers_output_cache, torch.slice(_41, 2))
    _43 = torch.append(r_conformer_cnn_cache, new_cnn_cache1)
    _44 = torch.__is__(elayers_output_cache4, None)
    if _44:
      attn_cache2, elayers_output_cache6 = None, elayers_output_cache4
    else:
      elayers_output_cache7 = unchecked_cast(List[Tensor], elayers_output_cache4)
      attn_cache2, elayers_output_cache6 = elayers_output_cache7[3], elayers_output_cache7
    _45 = torch.__is__(conformer_cnn_cache4, None)
    if _45:
      cnn_cache2, conformer_cnn_cache6 = None, conformer_cnn_cache4
    else:
      conformer_cnn_cache7 = unchecked_cast(List[Tensor], conformer_cnn_cache4)
      cnn_cache2, conformer_cnn_cache6 = conformer_cnn_cache7[3], conformer_cnn_cache7
    _46 = (_3).forward(xs15, masks1, pos_emb0, None, attn_cache2, cnn_cache2, )
    xs16, _47, new_cnn_cache2, = _46
    _48 = torch.slice(torch.slice(xs16), 1, next_cache_start)
    _49 = torch.append(r_elayers_output_cache, torch.slice(_48, 2))
    _50 = torch.append(r_conformer_cnn_cache, new_cnn_cache2)
    _51 = torch.__is__(elayers_output_cache6, None)
    if _51:
      attn_cache3, elayers_output_cache8 = None, elayers_output_cache6
    else:
      elayers_output_cache9 = unchecked_cast(List[Tensor], elayers_output_cache6)
      attn_cache3, elayers_output_cache8 = elayers_output_cache9[4], elayers_output_cache9
    _52 = torch.__is__(conformer_cnn_cache6, None)
    if _52:
      cnn_cache3, conformer_cnn_cache8 = None, conformer_cnn_cache6
    else:
      conformer_cnn_cache9 = unchecked_cast(List[Tensor], conformer_cnn_cache6)
      cnn_cache3, conformer_cnn_cache8 = conformer_cnn_cache9[4], conformer_cnn_cache9
    _53 = (_4).forward(xs16, masks1, pos_emb0, None, attn_cache3, cnn_cache3, )
    xs17, _54, new_cnn_cache3, = _53
    _55 = torch.slice(torch.slice(xs17), 1, next_cache_start)
    _56 = torch.append(r_elayers_output_cache, torch.slice(_55, 2))
    _57 = torch.append(r_conformer_cnn_cache, new_cnn_cache3)
    _58 = torch.__is__(elayers_output_cache8, None)
    if _58:
      attn_cache4 : Optional[Tensor] = None
    else:
      elayers_output_cache10 = unchecked_cast(List[Tensor], elayers_output_cache8)
      attn_cache4 = elayers_output_cache10[5]
    _59 = torch.__is__(conformer_cnn_cache8, None)
    if _59:
      cnn_cache4 : Optional[Tensor] = None
    else:
      conformer_cnn_cache10 = unchecked_cast(List[Tensor], conformer_cnn_cache8)
      cnn_cache4 = conformer_cnn_cache10[5]
    _60 = (_5).forward(xs17, masks1, pos_emb0, None, attn_cache4, cnn_cache4, )
    xs18, _61, new_cnn_cache4, = _60
    _62 = torch.slice(torch.slice(xs18), 1, next_cache_start)
    _63 = torch.append(r_elayers_output_cache, torch.slice(_62, 2))
    _64 = torch.append(r_conformer_cnn_cache, new_cnn_cache4)
    normalize_before = self.normalize_before
    if normalize_before:
      after_norm = self.after_norm
      xs19 = (after_norm).forward(xs18, )
    else:
      xs19 = xs18
    _65 = torch.slice(torch.slice(xs19), 1, cache_size)
    _66 = (torch.slice(_65, 2), r_subsampling_cache, r_elayers_output_cache, r_conformer_cnn_cache)
    return _66
