class Linear(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_features : int
  out_features : int
  scale : float
  zero_point : int
  version : int
  _packed_params : __torch__.torch.nn.quantized.modules.linear.LinearPackedParams
  def forward(self: __torch__.torch.nn.quantized.dynamic.modules.linear.Linear,
    x: Tensor) -> Tensor:
    _0 = "Unsupported dtype on dynamic quantized linear!"
    _1 = uninitialized(Tensor)
    _packed_params = self._packed_params
    dtype = _packed_params.dtype
    if torch.eq(dtype, 12):
      version = self.version
      if torch.lt(version, 4):
        _packed_params0 = self._packed_params
        _packed_params1 = _packed_params0._packed_params
        Y1 = ops.quantized.linear_dynamic(x, _packed_params1)
        Y0 = Y1
      else:
        _packed_params2 = self._packed_params
        _packed_params3 = _packed_params2._packed_params
        Y2 = ops.quantized.linear_dynamic(x, _packed_params3, True)
        Y0 = Y2
      Y = Y0
    else:
      _packed_params4 = self._packed_params
      dtype0 = _packed_params4.dtype
      if torch.eq(dtype0, 5):
        _packed_params5 = self._packed_params
        _packed_params6 = _packed_params5._packed_params
        Y4 = ops.quantized.linear_dynamic_fp16(x, _packed_params6)
        Y3 = Y4
      else:
        ops.prim.RaiseException(_0)
        Y3 = _1
      Y = Y3
    return torch.to(Y, ops.prim.dtype(x))
