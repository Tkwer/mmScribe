class LinearPackedParams(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dtype : int
  _packed_params : __torch__.torch.classes.quantized.LinearPackedParamsBase
  def forward(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    x: Tensor) -> Tensor:
    return x
  def __getstate__(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams) -> Tuple[Tensor, Optional[Tensor], bool, int]:
    qweight, bias, = (self)._weight_bias()
    training = self.training
    dtype = self.dtype
    return (qweight, bias, training, dtype)
  def __setstate__(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    state: Tuple[Tensor, Optional[Tensor], bool, int]) -> NoneType:
    self.dtype = (state)[3]
    _0 = (self).set_weight_bias((state)[0], (state)[1], )
    self.training = (state)[2]
    return None
  def _weight_bias(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams) -> Tuple[Tensor, Optional[Tensor]]:
    _1 = "Unsupported dtype on dynamic quantized linear!"
    _2 = uninitialized(Tuple[Tensor, Optional[Tensor]])
    dtype = self.dtype
    if torch.eq(dtype, 12):
      _packed_params = self._packed_params
      _4, _5 = ops.quantized.linear_unpack(_packed_params)
      _3 = (_4, _5)
    else:
      dtype0 = self.dtype
      if torch.eq(dtype0, 5):
        _packed_params0 = self._packed_params
        _7, _8 = ops.quantized.linear_unpack_fp16(_packed_params0)
        _6 = (_7, _8)
      else:
        ops.prim.RaiseException(_1)
        _6 = _2
      _3 = _6
    return _3
  def set_weight_bias(self: __torch__.torch.nn.quantized.modules.linear.LinearPackedParams,
    weight: Tensor,
    bias: Optional[Tensor]) -> NoneType:
    _9 = "Unsupported dtype on dynamic quantized linear!"
    dtype = self.dtype
    if torch.eq(dtype, 12):
      _10 = ops.quantized.linear_prepack(weight, bias)
      self._packed_params = _10
    else:
      dtype1 = self.dtype
      if torch.eq(dtype1, 5):
        _11 = ops.quantized.linear_prepack_fp16(weight, bias)
        self._packed_params = _11
      else:
        ops.prim.RaiseException(_9)
    return None
