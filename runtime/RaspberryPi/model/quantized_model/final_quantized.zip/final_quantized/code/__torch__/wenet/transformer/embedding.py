class RelPositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.wenet.transformer.embedding.RelPositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _0 = torch.add(offset, torch.size(x, 1))
    max_len = self.max_len
    if torch.lt(_0, max_len):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    pe = self.pe
    self.pe = torch.to(pe, ops.prim.device(x))
    xscale = self.xscale
    x0 = torch.mul(x, xscale)
    pe0 = self.pe
    _1 = torch.slice(pe0)
    _2 = torch.add(offset, torch.size(x0, 1))
    pos_emb = torch.slice(_1, 1, offset, _2)
    dropout = self.dropout
    _3 = (dropout).forward(x0, )
    dropout0 = self.dropout
    return (_3, (dropout0).forward(pos_emb, ))
  def position_encoding(self: __torch__.wenet.transformer.embedding.RelPositionalEncoding,
    offset: int,
    size: int) -> Tensor:
    _4 = torch.add(offset, size)
    max_len = self.max_len
    if torch.lt(_4, max_len):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    dropout = self.dropout
    pe = self.pe
    _5 = torch.slice(torch.slice(pe), 1, offset, torch.add(offset, size))
    return (dropout).forward(_5, )
class PositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.wenet.transformer.embedding.PositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _6 = torch.add(offset, torch.size(x, 1))
    max_len = self.max_len
    if torch.lt(_6, max_len):
      pass
    else:
      ops.prim.RaiseException("AssertionError: ")
    pe = self.pe
    self.pe = torch.to(pe, ops.prim.device(x))
    pe1 = self.pe
    pos_emb = torch.slice(torch.slice(pe1), 1, offset, torch.add(offset, torch.size(x, 1)))
    xscale = self.xscale
    x1 = torch.add(torch.mul(x, xscale), pos_emb)
    dropout = self.dropout
    _7 = (dropout).forward(x1, )
    dropout1 = self.dropout
    return (_7, (dropout1).forward(pos_emb, ))
