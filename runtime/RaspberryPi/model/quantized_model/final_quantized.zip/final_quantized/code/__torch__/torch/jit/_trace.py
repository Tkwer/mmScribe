def is_tracing() -> bool:
  return False
