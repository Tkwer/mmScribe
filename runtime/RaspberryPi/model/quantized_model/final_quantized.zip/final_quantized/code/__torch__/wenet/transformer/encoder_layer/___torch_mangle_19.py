class ConformerEncoderLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  ff_scale : float
  size : int
  normalize_before : bool
  concat_after : bool
  self_attn : __torch__.wenet.transformer.attention.___torch_mangle_17.RelPositionMultiHeadedAttention
  feed_forward : __torch__.wenet.transformer.positionwise_feed_forward.___torch_mangle_18.PositionwiseFeedForward
  feed_forward_macaron : __torch__.wenet.transformer.positionwise_feed_forward.___torch_mangle_18.PositionwiseFeedForward
  conv_module : __torch__.wenet.transformer.convolution.ConvolutionModule
  norm_ff : __torch__.torch.nn.modules.normalization.LayerNorm
  norm_mha : __torch__.torch.nn.modules.normalization.LayerNorm
  norm_ff_macaron : __torch__.torch.nn.modules.normalization.LayerNorm
  norm_conv : __torch__.torch.nn.modules.normalization.LayerNorm
  norm_final : __torch__.torch.nn.modules.normalization.LayerNorm
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  concat_linear : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  def forward(self: __torch__.wenet.transformer.encoder_layer.___torch_mangle_19.ConformerEncoderLayer,
    x: Tensor,
    mask: Tensor,
    pos_emb: Tensor,
    mask_pad: Optional[Tensor]=None,
    output_cache: Optional[Tensor]=None,
    cnn_cache: Optional[Tensor]=None) -> Tuple[Tensor, Tensor, Tensor]:
    normalize_before = self.normalize_before
    if normalize_before:
      norm_ff_macaron = self.norm_ff_macaron
      x0 = (norm_ff_macaron).forward(x, )
    else:
      x0 = x
    ff_scale = self.ff_scale
    dropout = self.dropout
    feed_forward_macaron = self.feed_forward_macaron
    _0 = (feed_forward_macaron).forward(x0, )
    _1 = torch.mul((dropout).forward(_0, ), ff_scale)
    x1 = torch.add(x, _1)
    normalize_before0 = self.normalize_before
    if torch.__not__(normalize_before0):
      norm_ff_macaron0 = self.norm_ff_macaron
      x2 = (norm_ff_macaron0).forward(x1, )
    else:
      x2 = x1
    normalize_before1 = self.normalize_before
    if normalize_before1:
      norm_mha = self.norm_mha
      x3 = (norm_mha).forward(x2, )
    else:
      x3 = x2
    if torch.__is__(output_cache, None):
      x_q, mask0, residual, output_cache0 = x3, mask, x2, output_cache
    else:
      output_cache1 = unchecked_cast(Tensor, output_cache)
      _2 = torch.eq(torch.size(output_cache1, 0), torch.size(x3, 0))
      if _2:
        pass
      else:
        ops.prim.RaiseException("AssertionError: ")
      _3 = torch.size(output_cache1, 2)
      size = self.size
      if torch.eq(_3, size):
        pass
      else:
        ops.prim.RaiseException("AssertionError: ")
      _4 = torch.lt(torch.size(output_cache1, 1), torch.size(x3, 1))
      if _4:
        pass
      else:
        ops.prim.RaiseException("AssertionError: ")
      chunk = torch.sub(torch.size(x3, 1), torch.size(output_cache1, 1))
      _5 = torch.slice(torch.slice(x3), 1, torch.neg(chunk))
      x_q0 = torch.slice(_5, 2)
      _6 = torch.slice(torch.slice(x2), 1, torch.neg(chunk))
      residual0 = torch.slice(_6, 2)
      _7 = torch.slice(torch.slice(mask), 1, torch.neg(chunk))
      x_q, mask0, residual, output_cache0 = x_q0, torch.slice(_7, 2), residual0, output_cache1
    self_attn = self.self_attn
    x_att = (self_attn).forward(x_q, x3, x3, mask0, pos_emb, )
    concat_after = self.concat_after
    if concat_after:
      x_concat = torch.cat([x3, x_att], -1)
      concat_linear = self.concat_linear
      _8 = (concat_linear).forward(x_concat, )
      x4 = torch.add(residual, _8)
    else:
      dropout0 = self.dropout
      x5 = torch.add(residual, (dropout0).forward(x_att, ))
      x4 = x5
    normalize_before2 = self.normalize_before
    if torch.__not__(normalize_before2):
      norm_mha0 = self.norm_mha
      x6 = (norm_mha0).forward(x4, )
    else:
      x6 = x4
    normalize_before3 = self.normalize_before
    if normalize_before3:
      norm_conv = self.norm_conv
      x7 = (norm_conv).forward(x6, )
    else:
      x7 = x6
    conv_module = self.conv_module
    _9 = (conv_module).forward(x7, mask_pad, cnn_cache, )
    x8, new_cnn_cache, = _9
    dropout1 = self.dropout
    x9 = torch.add(x6, (dropout1).forward(x8, ))
    normalize_before4 = self.normalize_before
    if torch.__not__(normalize_before4):
      norm_conv0 = self.norm_conv
      x10 = (norm_conv0).forward(x9, )
    else:
      x10 = x9
    normalize_before5 = self.normalize_before
    if normalize_before5:
      norm_ff = self.norm_ff
      x11 = (norm_ff).forward(x10, )
    else:
      x11 = x10
    ff_scale0 = self.ff_scale
    dropout2 = self.dropout
    feed_forward = self.feed_forward
    _10 = (dropout2).forward((feed_forward).forward(x11, ), )
    x12 = torch.add(x10, torch.mul(_10, ff_scale0))
    normalize_before6 = self.normalize_before
    if torch.__not__(normalize_before6):
      norm_ff0 = self.norm_ff
      x13 = (norm_ff0).forward(x12, )
    else:
      x13 = x12
    norm_final = self.norm_final
    x14 = (norm_final).forward(x13, )
    _11 = torch.__isnot__(output_cache0, None)
    if _11:
      output_cache2 = unchecked_cast(Tensor, output_cache0)
      x16 = torch.cat([output_cache2, x14], 1)
      x15 = x16
    else:
      x15 = x14
    return (x15, mask0, new_cnn_cache)
