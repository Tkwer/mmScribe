class DecoderLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  size : int
  normalize_before : bool
  concat_after : bool
  self_attn : __torch__.wenet.transformer.attention.MultiHeadedAttention
  src_attn : __torch__.wenet.transformer.attention.MultiHeadedAttention
  feed_forward : __torch__.wenet.transformer.positionwise_feed_forward.___torch_mangle_13.PositionwiseFeedForward
  norm1 : __torch__.torch.nn.modules.normalization.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.LayerNorm
  norm3 : __torch__.torch.nn.modules.normalization.LayerNorm
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  concat_linear1 : __torch__.torch.nn.modules.linear.___torch_mangle_10.Linear
  concat_linear2 : __torch__.torch.nn.modules.linear.___torch_mangle_10.Linear
  def forward(self: __torch__.wenet.transformer.decoder_layer.DecoderLayer,
    tgt: Tensor,
    tgt_mask: Tensor,
    memory: Tensor,
    memory_mask: Tensor,
    cache: Optional[Tensor]=None) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    _0 = "AssertionError: {cache.shape} == {(tgt.shape[0], tgt.shape[1] - 1, self.size)}"
    normalize_before = self.normalize_before
    if normalize_before:
      norm1 = self.norm1
      tgt0 = (norm1).forward(tgt, )
    else:
      tgt0 = tgt
    if torch.__is__(cache, None):
      tgt_q, tgt_q_mask, residual, cache0 = tgt0, tgt_mask, tgt, cache
    else:
      cache1 = unchecked_cast(Tensor, cache)
      _1 = torch.size(cache1)
      _2 = (torch.size(tgt0))[0]
      _3 = torch.sub((torch.size(tgt0))[1], 1)
      size = self.size
      if torch.eq(_1, [_2, _3, size]):
        pass
      else:
        ops.prim.RaiseException(_0)
      _4 = torch.slice(torch.slice(tgt0), 1, -1)
      tgt_q0 = torch.slice(_4, 2)
      _5 = torch.slice(torch.slice(tgt), 1, -1)
      residual0 = torch.slice(_5, 2)
      _6 = torch.slice(torch.slice(tgt_mask), 1, -1)
      tgt_q, tgt_q_mask, residual, cache0 = tgt_q0, torch.slice(_6, 2), residual0, cache1
    concat_after = self.concat_after
    if concat_after:
      self_attn = self.self_attn
      _7 = (self_attn).forward(tgt_q, tgt0, tgt0, tgt_q_mask, CONSTANTS.c0, )
      tgt_concat = torch.cat([tgt_q, _7], -1)
      concat_linear1 = self.concat_linear1
      _8 = (concat_linear1).forward(tgt_concat, )
      x = torch.add(residual, _8)
    else:
      dropout = self.dropout
      self_attn0 = self.self_attn
      _9 = (self_attn0).forward(tgt_q, tgt0, tgt0, tgt_q_mask, CONSTANTS.c0, )
      x0 = torch.add(residual, (dropout).forward(_9, ))
      x = x0
    normalize_before0 = self.normalize_before
    if torch.__not__(normalize_before0):
      norm10 = self.norm1
      x1 = (norm10).forward(x, )
    else:
      x1 = x
    normalize_before1 = self.normalize_before
    if normalize_before1:
      norm2 = self.norm2
      x2 = (norm2).forward(x1, )
    else:
      x2 = x1
    concat_after0 = self.concat_after
    if concat_after0:
      src_attn = self.src_attn
      _10 = (src_attn).forward(x2, memory, memory, memory_mask, CONSTANTS.c0, )
      x_concat = torch.cat([x2, _10], -1)
      concat_linear2 = self.concat_linear2
      _11 = (concat_linear2).forward(x_concat, )
      x3 = torch.add(x1, _11)
    else:
      dropout0 = self.dropout
      src_attn0 = self.src_attn
      _12 = (src_attn0).forward(x2, memory, memory, memory_mask, CONSTANTS.c0, )
      x4 = torch.add(x1, (dropout0).forward(_12, ))
      x3 = x4
    normalize_before2 = self.normalize_before
    if torch.__not__(normalize_before2):
      norm20 = self.norm2
      x5 = (norm20).forward(x3, )
    else:
      x5 = x3
    normalize_before3 = self.normalize_before
    if normalize_before3:
      norm3 = self.norm3
      x6 = (norm3).forward(x5, )
    else:
      x6 = x5
    dropout1 = self.dropout
    feed_forward = self.feed_forward
    _13 = (dropout1).forward((feed_forward).forward(x6, ), )
    x7 = torch.add(x5, _13)
    normalize_before4 = self.normalize_before
    if torch.__not__(normalize_before4):
      norm30 = self.norm3
      x8 = (norm30).forward(x7, )
    else:
      x8 = x7
    if torch.__isnot__(cache0, None):
      cache2 = unchecked_cast(Tensor, cache0)
      x9 = torch.cat([cache2, x8], 1)
    else:
      x9 = x8
    return (x9, tgt_mask, memory, memory_mask)
