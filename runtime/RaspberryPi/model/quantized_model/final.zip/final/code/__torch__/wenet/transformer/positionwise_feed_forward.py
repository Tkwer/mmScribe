class PositionwiseFeedForward(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  w_1 : __torch__.torch.nn.modules.linear.___torch_mangle_5.Linear
  activation : __torch__.torch.nn.modules.activation.SiLU
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  w_2 : __torch__.torch.nn.modules.linear.___torch_mangle_6.Linear
  def forward(self: __torch__.wenet.transformer.positionwise_feed_forward.PositionwiseFeedForward,
    xs: Tensor) -> Tensor:
    w_2 = self.w_2
    dropout = self.dropout
    activation = self.activation
    w_1 = self.w_1
    _0 = (activation).forward((w_1).forward(xs, ), )
    _1 = (w_2).forward((dropout).forward(_0, ), )
    return _1
