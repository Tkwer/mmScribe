class Conv2dSubsampling4(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  right_context : int
  subsampling_rate : int
  conv : __torch__.torch.nn.modules.container.Sequential
  out : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  pos_enc : __torch__.wenet.transformer.embedding.RelPositionalEncoding
  def forward(self: __torch__.wenet.transformer.subsampling.Conv2dSubsampling4,
    x: Tensor,
    x_mask: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor, Tensor]:
    x0 = torch.unsqueeze(x, 1)
    conv = self.conv
    x1 = (conv).forward(x0, )
    b, c, t, f, = torch.size(x1)
    out = self.out
    _0 = torch.contiguous(torch.transpose(x1, 1, 2))
    _1 = torch.view(_0, [b, t, torch.mul(c, f)])
    x2 = (out).forward(_1, )
    pos_enc = self.pos_enc
    x3, pos_emb, = (pos_enc).forward(x2, offset, )
    _2 = torch.slice(torch.slice(torch.slice(x_mask), 1), 2, None, -2, 2)
    _3 = torch.slice(torch.slice(torch.slice(_2), 1), 2, None, -2, 2)
    return (x3, pos_emb, _3)
  def position_encoding(self: __torch__.wenet.transformer.subsampling.Conv2dSubsampling4,
    offset: int,
    size: int) -> Tensor:
    pos_enc = self.pos_enc
    _4 = (pos_enc).position_encoding(offset, size, )
    return _4
