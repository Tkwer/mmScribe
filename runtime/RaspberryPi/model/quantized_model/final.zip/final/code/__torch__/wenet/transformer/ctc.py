class CTC(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dropout_rate : float
  ctc_lo : __torch__.torch.nn.modules.linear.___torch_mangle_12.Linear
  ctc_loss : __torch__.torch.nn.modules.loss.CTCLoss
  def forward(self: __torch__.wenet.transformer.ctc.CTC,
    hs_pad: Tensor,
    hlens: Tensor,
    ys_pad: Tensor,
    ys_lens: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.dropout
    ctc_lo = self.ctc_lo
    dropout_rate = self.dropout_rate
    _1 = _0(hs_pad, dropout_rate, True, False, )
    ys_hat = (ctc_lo).forward(_1, )
    ys_hat0 = torch.transpose(ys_hat, 0, 1)
    ys_hat1 = torch.log_softmax(ys_hat0, 2)
    ctc_loss = self.ctc_loss
    loss = (ctc_loss).forward(ys_hat1, ys_pad, hlens, ys_lens, )
    loss0 = torch.div(loss, torch.size(ys_hat1, 1))
    return loss0
  def log_softmax(self: __torch__.wenet.transformer.ctc.CTC,
    hs_pad: Tensor) -> Tensor:
    _2 = __torch__.torch.nn.functional.log_softmax
    ctc_lo = self.ctc_lo
    _3 = _2((ctc_lo).forward(hs_pad, ), 2, 3, None, )
    return _3
